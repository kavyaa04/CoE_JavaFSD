export interface Challenge {
    id: number;
    name: string;
    difficulty: string;
    description: string;
    descriptionDetail: string;
  }
  